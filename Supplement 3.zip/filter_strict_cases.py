import pandas as pd
import re

# Load the previously filtered human dataset
input_file = 'case_reports_human.csv'
output_strict_file = 'case_reports_strict.csv'
output_excluded_file = 'case_reports_non_toxo_excluded.csv'

try:
    df = pd.read_csv(input_file)
    print(f"Loaded {len(df)} records from {input_file}")
except FileNotFoundError:
    print(f"Error: {input_file} not found.")
    exit(1)

# Diagnostic confirmation keywords
diag_keywords = [
    r'elisa', r'western blot', r'serolog', r'seropositive', r'antibodies', r'antibody',
    r'igg', r'igm', r'histolog', r'biopsy', r'larva', r'patholog', r'pcr', r'molecular'
]
diag_pattern = '|'.join(diag_keywords)

def categorize_case(row):
    title = str(row.get('Title', ''))
    abstract = str(row.get('Raw_Abstract', ''))
    text_to_search = (title + " " + abstract).lower()
    
    # 1. First, must be about Toxocariasis
    inclusion_keywords = [r'toxocara', r'toxocariasis', r'toxocarosis', r'larva migrans']
    if not re.search('|'.join(inclusion_keywords), text_to_search):
        return 'Excluded (Non-Toxocariasis focus)'
        
    # 2. Strict Operational Criteria: Must have objective proof
    if not re.search(diag_pattern, text_to_search):
        return 'Excluded (Uncertain Diagnosis - No Serology/Biopsy mentioned)'
        
    # 3. Exclude 'presumed' if testing was explicitly negative or skipped
    if 'presumed' in title.lower() or 'suspected' in title.lower():
        # It's kept ONLY if they did test it in the abstract
        if not re.search(diag_pattern, abstract.lower()):
            return 'Excluded (Uncertain Diagnosis - Suspected only)'
    
    return 'Kept'

df['Filter_Category'] = df.apply(categorize_case, axis=1)

strict_df = df[df['Filter_Category'] == 'Kept'].drop(columns=['Filter_Category'])
excluded_df = df[df['Filter_Category'] != 'Kept']

strict_df.to_csv(output_strict_file, index=False)
excluded_df.to_csv(output_excluded_file, index=False)

print(f"Strict filtering complete based on Operational Criteria.")
print(f"Total records input: {len(df)}")
print(f"Strict cases kept: {len(strict_df)}")
print(f"Excluded cases: {len(excluded_df)}")
print("\nExclusion Breakdown:")
print(excluded_df['Filter_Category'].value_counts() if not excluded_df.empty else "None")
