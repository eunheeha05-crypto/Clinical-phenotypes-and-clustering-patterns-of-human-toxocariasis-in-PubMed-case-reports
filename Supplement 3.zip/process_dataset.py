import pandas as pd
import re
import json
import os

df = pd.read_csv('case_reports.csv')
total_fetched = len(df)

# Load full texts if available
pmid_fulltexts = {}
if os.path.exists('pmid_fulltexts.json'):
    with open('pmid_fulltexts.json', 'r', encoding='utf-8') as f:
        pmid_fulltexts = json.load(f)

# 1. Filter Non-human
def is_human(row):
    title = str(row.get('Title', '')).lower()
    abstract = str(row.get('Raw_Abstract', '')).lower()
    text = title + " " + abstract
    
    if re.search(r'\bin a dog\b|\bin a cat\b|\bin dogs\b|\bin cats\b|\banimal model\b', title):
        return False
    if re.search(r'\bveterinary\b', title) and not re.search(r'\b(student|worker|technician|staff|profession)\b', title):
        return False
    strong_animals = r'\b(cat|cats|dog|dogs|macaque|macaques|mice|mouse|rat|rats|feline|canine|horse|horses|cow|cows|foal|foals|opossum|didelphis|pig|pigs|sheep|alpaca|porcine|bovine|equine|puppy|puppies|kitten|kittens)\b'
    if re.search(strong_animals, title) and not re.search(r'\b(human|man|woman|boy|girl|patient|child|infant|consumption|eating|ingestion|food|meat)\b', title):
        if not re.search(r'\b(human|man|woman|boy|girl|patient|child|infant|consumption|eating|ingestion|food|meat)\b', abstract):
            return False 

    # Strong veterinary indicators in Abstract
    if re.search(r'\b(dog|cat|horse|cow|animal)s?\b was presented', text):
        return False
    if re.search(r'\b(?:presented to the veterinary|admitted to the veterinary)\b', text):
        return False
    if re.search(r'a \d+[- ](?:year|month|week|day)[- ]old (?:dog|cat|horse|cow)\b', text):
        return False
        
    return True

df = df[df.apply(is_human, axis=1)].copy()
human_kept = len(df)

# 2. Filter Strict (Serology / Histology / Diagnosis)
diag_pattern = r'elisa|western blot|serolog|seropositive|antibodies|antibody|igg|igm|histolog|biopsy|larva|patholog|pcr|molecular|polymerase chain reaction|imaging|mri|oct|clinical|eosinophi|funduscopy|ultrasound'

def is_strict(row):
    title = str(row.get('Title', ''))
    abstract_val = row.get('Raw_Abstract')
    abstract = str(abstract_val) if pd.notna(abstract_val) else ''
    pmid = str(row.get('PMID', ''))
    fulltext = str(pmid_fulltexts.get(pmid, ''))
    
    text_to_search = (title + " " + abstract + " " + fulltext).lower()
    
    # Must explicitly mention toxocara/larva migrans
    if not re.search(r'toxocara|toxocariasis|toxocarosis|larva migrans', text_to_search):
        return False
        
    # If PubMed gave us no abstract and no PMC full text but the title clearly says toxocariasis, we safely include it
    is_fulltext_empty = not fulltext or fulltext == "No Abstract Found" or fulltext == "Error Fetching Abstract"
    if pd.isna(abstract_val) and is_fulltext_empty and re.search(r'toxocariasis|toxocarosis', title.lower()):
        return True

    if not re.search(diag_pattern, text_to_search):
        return False # Drop uncertain
    return True

df = df[df.apply(is_strict, axis=1)].copy()
strict_kept = len(df)

# 3. Classify Organ Involvement
def extract_organs(row):
    title = str(row.get('Title', ''))
    abstract = str(row.get('Raw_Abstract', ''))
    pmid = str(row.get('PMID', ''))
    fulltext = str(pmid_fulltexts.get(pmid, ''))
    
    text = (title + " " + abstract + " " + fulltext).lower()
    organs = []
    
    # Eye
    if re.search(r'eye|ocular|vision|uveitis|retina|macula|blindness|optic', text):
        organs.append('Eye (OLM)')
        
    # CNS
    if re.search(r'cns|neuro|brain|seizure|meningitis|encephal|spinal', text):
        organs.append('CNS (Neurotoxocariasis)')
        
    # Liver
    if re.search(r'liver|hepatic|hepatomegaly', text):
        organs.append('Liver')
        
    # Lung
    if re.search(r'lung|pulmonary|asthma|cough|pneumo|respiratory', text):
        organs.append('Lung')
        
    # Heart
    if re.search(r'heart|cardiac|myocard|pericard', text):
        organs.append('Heart')
        
    if not organs:
        if re.search(r'systemic|visceral', text):
            organs.append('Systemic (VLM)')
        else:
            organs.append('None/Systemic')
            
    return ", ".join(organs)

df['Organ Involvement'] = df.apply(extract_organs, axis=1)

# Drop redundant symptom columns to fix the tautology
if 'Symptoms (MeSH)' in df.columns:
    df['Symptoms (MeSH)'] = "Mapped internally to Organs"
else:
    df['Symptoms (MeSH)'] = "Mapped internally to Organs"

df.to_csv('case_reports_final.csv', index=False)

print("PROCESS DATASET COMPLETE")
print(f"Total PubMed Fetched: {total_fetched}")
print(f"After Human Filter: {human_kept}")
print(f"After Strict Operational Criteria: {strict_kept}")
