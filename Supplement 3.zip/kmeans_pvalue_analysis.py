import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from scipy.stats import fisher_exact
import os

def main():
    print("Loading MeSH standardized data...")
    df = pd.read_csv("case_reports_mesh_standardized.csv")

    # 1. One-hot encode MeSH symptoms
    all_symptoms = set()
    for item in df['MeSH_Symptoms']:
        if pd.isna(item) or item == "Asymptomatic/Covert":
            continue
        terms = [t.strip() for t in item.split(',')]
        all_symptoms.update(terms)
        
    symptoms_list = sorted(list(all_symptoms))
    print(f"Found {len(symptoms_list)} unique MeSH symptoms.")

    symptom_data = []
    for index, row in df.iterrows():
        row_symptoms = row['MeSH_Symptoms']
        row_dict = {}
        if pd.isna(row_symptoms) or row_symptoms == "Asymptomatic/Covert":
            current_symptoms = []
        else:
            current_symptoms = [t.strip() for t in row_symptoms.split(',')]
            
        for sym in symptoms_list:
            row_dict[sym] = 1 if sym in current_symptoms else 0
        symptom_data.append(row_dict)
        
    df_symptoms = pd.DataFrame(symptom_data)

    # Filter out rare features (< 2 occurrences) to reduce noise in clustering and fisher
    df_model = df_symptoms.loc[:, (df_symptoms.sum(axis=0) >= 2)]
    print(f"Modeling with {df_model.shape[1]} features.")

    # 2. K-Means Clustering (K=4 to capture VLM, OLM, Neuro, Covert)
    kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
    clusters = kmeans.fit_predict(df_model)
    df['MeSH_Cluster'] = clusters

    # 3. Generating Co-occurrence Heatmap
    print("Generating Co-occurrence heatmap...")
    # calculating co-occurrence directly via dot product or corr
    coocc = df_model.T.dot(df_model)
    for i in range(len(coocc.columns)):
        coocc.iloc[i, i] = 0 # hide self relation for clarity
    
    plt.figure(figsize=(10, 8))
    sns.heatmap(coocc, cmap='Blues', annot=True, fmt='d')
    plt.title("MeSH Symptom Co-occurrence Counts")
    plt.tight_layout()
    plt.savefig("mesh_cooccurrence_heatmap.png", dpi=300)
    
    # 4. Fisher's Exact Test for P-values
    print("Generating P-Value significance heatmap...")
    features = df_model.columns.tolist()
    n_feat = len(features)
    p_matrix = np.ones((n_feat, n_feat)) # Fill with 1.0 initially
    
    for i in range(n_feat):
        for j in range(i+1, n_feat):
            f1 = features[i]
            f2 = features[j]
            crosstab = pd.crosstab(df_model[f1], df_model[f2])
            
            # Pad if missing zeroes
            if crosstab.shape != (2,2):
                p_value = 1.0
            else:
                odds, p_value = fisher_exact(crosstab)
            
            # We plot -log10(p) for visualization
            p_matrix[i, j] = p_value
            p_matrix[j, i] = p_value

    log_p_matrix = -np.log10(p_matrix + 1e-15) # Add epsilon to avoid log(0)
    
    plt.figure(figsize=(12, 10))
    sns.heatmap(log_p_matrix, xticklabels=features, yticklabels=features, 
                cmap='Reds', vmin=0, vmax=3, annot=True, fmt=".1f") # vmax=3 is P=0.001
    plt.title("Significance of Symptom Associations (-log10 $p$-value)")
    plt.tight_layout()
    plt.savefig("mesh_pvalue_significance_heatmap.png", dpi=300)
    
    # Text Report
    with open("mesh_analysis_report.md", "w") as f:
        f.write("# MeSH Symptom Analysis Report\n\n")
        f.write("## K-Means Tautology-Free Clusters (K=4)\n")
        for k in range(4):
            c_size = len(df[df['MeSH_Cluster'] == k])
            f.write(f"### Cluster {k} (n={c_size})\n")
            c_idx = df[df['MeSH_Cluster'] == k].index
            means = df_model.loc[c_idx].mean().sort_values(ascending=False) * 100
            for feat, val in means.items():
                if val > 15:
                    f.write(f"- {feat}: {val:.1f}%\n")
            f.write("\n")
            
        f.write("## Highly Significant Associations (Fisher P < 0.05)\n")
        for i in range(n_feat):
            for j in range(i+1, n_feat):
                if p_matrix[i, j] < 0.05:
                    f.write(f"- **{features[i]}** & **{features[j]}**: p = {p_matrix[i, j]:.4f}\n")

    print("Success: Generated K-Means models and Fisher P-value heatmaps")

if __name__ == "__main__":
    main()
