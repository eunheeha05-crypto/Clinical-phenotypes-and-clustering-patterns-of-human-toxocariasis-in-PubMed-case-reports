import pandas as pd
import itertools

def main():
    print("Loading case_reports_mesh_standardized.csv...")
    df = pd.read_csv("case_reports_mesh_standardized.csv")
    
    # 1. Extract and one-hot encode MeSH symptoms
    all_symptoms = set()
    for item in df['MeSH_Symptoms']:
        if pd.isna(item) or item == "Asymptomatic/Covert":
            continue
        terms = [t.strip() for t in item.split(',')]
        all_symptoms.update(terms)
        
    symptoms_list = sorted(list(all_symptoms))
    
    symptom_data = []
    for index, row in df.iterrows():
        row_symptoms = row['MeSH_Symptoms']
        row_dict = {}
        if pd.isna(row_symptoms) or row_symptoms == "Asymptomatic/Covert":
            current_symptoms = []
        else:
            current_symptoms = [t.strip() for t in row_symptoms.split(',')]
            
        for sym in symptoms_list:
            row_dict[sym] = 1 if sym in current_symptoms else 0
        symptom_data.append(row_dict)
        
    df_symptoms = pd.DataFrame(symptom_data)
    
    # Filter features that have at least 2 occurrences (same as generate_overall_summary.py)
    df_model = df_symptoms.loc[:, (df_symptoms.sum(axis=0) >= 2)]
    features = df_model.columns.tolist()
    
    print(f"Generating 2x2 contingency tables for {len(features)} features...")
    
    results = []
    for s1, s2 in itertools.combinations(features, 2):
        crosstab = pd.crosstab(df_model[s1], df_model[s2])
        
        # In a 2x2 table:
        # Index 1 = Present, Index 0 = Absent for s1
        # Column 1 = Present, Column 0 = Absent for s2
        
        both_present = crosstab.loc[1, 1] if 1 in crosstab.index and 1 in crosstab.columns else 0
        s1_only = crosstab.loc[1, 0] if 1 in crosstab.index and 0 in crosstab.columns else 0
        s2_only = crosstab.loc[0, 1] if 0 in crosstab.index and 1 in crosstab.columns else 0
        neither = crosstab.loc[0, 0] if 0 in crosstab.index and 0 in crosstab.columns else 0
        
        results.append({
            "Symptom 1": s1,
            "Symptom 2": s2,
            "Both Present (S1+/S2+)": both_present,
            "S1 Only (S1+/S2-)": s1_only,
            "S2 Only (S1-/S2+)": s2_only,
            "Neither (S1-/S2-)": neither
        })
        
    res_df = pd.DataFrame(results)
    res_df.sort_values(by=["Both Present (S1+/S2+)"], ascending=[False], inplace=True)
    res_df.to_csv("Supplement 3_2x2_Contingency_Tables.csv", index=False)
    print("Exported to Supplement 3_2x2_Contingency_Tables.csv successfully.")

if __name__ == "__main__":
    main()
