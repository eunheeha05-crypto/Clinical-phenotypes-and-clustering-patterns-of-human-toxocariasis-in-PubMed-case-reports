import pandas as pd
import json
import time
import re
from Bio import Entrez
import os

Entrez.email = "toxocariasis_test@example.com"

df = pd.read_csv('case_reports.csv')
pmids = df['PMID'].dropna().astype(str).tolist()

print(f"Fetching PMC IDs for {len(pmids)} records using Entrez.elink...")
pmid_to_pmcid = {}

# Use Entrez.elink with chunks just to be safe
chunk_size = 10
for i in range(0, len(pmids), chunk_size):
    chunk = pmids[i:i+chunk_size]
    for attempt in range(3):
        try:
            results = Entrez.read(Entrez.elink(dbfrom='pubmed', db='pmc', id=chunk))
            for res in results:
                pmid = res['IdList'][0]
                link_sets = res.get('LinkSetDb', [])
                for link_set in link_sets:
                    if link_set['LinkName'] == 'pubmed_pmc':
                        pmcid = link_set['Link'][0]['Id']
                        pmid_to_pmcid[pmid] = pmcid
            break # success
        except Exception as e:
            print(f"Error fetching links for chunk {i}, attempt {attempt}: {e}")
            time.sleep(2)
    time.sleep(0.35)

print(f"Found PMC IDs for {len(pmid_to_pmcid)} records out of {len(pmids)}.")

pmid_to_text = {}
for idx, pmid in enumerate(pmids):
    pmcid = pmid_to_pmcid.get(pmid)
    if pmcid:
        if idx % 10 == 0:
            print(f"Fetching full text {idx}/{len(pmids)}...")
        try:
            handle = Entrez.efetch(db="pmc", id=pmcid, retmode="xml")
            xml_data = handle.read()
            if isinstance(xml_data, bytes):
                xml_data = xml_data.decode('utf-8', errors='ignore')
            text_content = re.sub(r'<[^>]+>', ' ', xml_data)
            pmid_to_text[pmid] = str(text_content)
        except Exception as e:
            pass
        time.sleep(0.35)
    else:
        if idx % 10 == 0:
            print(f"Fetching abstract for fallback {idx}/{len(pmids)}...")
        try:
            handle = Entrez.efetch(db="pubmed", id=pmid, retmode="xml")
            xml_data = handle.read()
            if isinstance(xml_data, bytes):
                xml_data = xml_data.decode('utf-8', errors='ignore')
            
            match = re.search(r'<AbstractText[^>]*>(.*?)</AbstractText>', xml_data, re.IGNORECASE | re.DOTALL)
            if match:
                abstract_text = re.sub(r'<[^>]+>', ' ', match.group(1))
                pmid_to_text[pmid] = str(abstract_text)
            else:
                pmid_to_text[pmid] = "No Abstract Found"
        except Exception as e:
            pmid_to_text[pmid] = "Error Fetching Abstract"
        time.sleep(0.35)

with open('pmid_fulltexts.json', 'w', encoding='utf-8') as f:
    json.dump(pmid_to_text, f)

print(f"Finished downloading full texts. Total extracted texts: {sum(1 for t in pmid_to_text.values() if len(t.strip()) > 50)}")
