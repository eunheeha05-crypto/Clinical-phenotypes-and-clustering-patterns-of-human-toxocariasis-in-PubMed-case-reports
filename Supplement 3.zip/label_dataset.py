import pandas as pd
import re
import json
import os

df = pd.read_csv('case_reports.csv')

# Load full texts
pmid_fulltexts = {}
if os.path.exists('pmid_fulltexts.json'):
    with open('pmid_fulltexts.json', 'r', encoding='utf-8') as f:
        pmid_fulltexts = json.load(f)

# Human filter logic identical to process_dataset.py
def is_human(row):
    title = str(row.get('Title', '')).lower()
    abstract = str(row.get('Raw_Abstract', '')).lower()
    text = title + " " + abstract
    if re.search(r'\bin a dog\b|\bin a cat\b|\bin dogs\b|\bin cats\b|\banimal model\b', title): return False
    if re.search(r'\bveterinary\b', title) and not re.search(r'\b(student|worker|technician|staff|profession)\b', title): return False
    strong_animals = r'\b(cat|cats|dog|dogs|macaque|macaques|mice|mouse|rat|rats|feline|canine|horse|horses|cow|cows|foal|foals|opossum|didelphis|pig|pigs|sheep|alpaca|porcine|bovine|equine|puppy|puppies|kitten|kittens)\b'
    if re.search(strong_animals, title) and not re.search(r'\b(human|man|woman|boy|girl|patient|child|infant|consumption|eating|ingestion|food|meat)\b', title):
        if not re.search(r'\b(human|man|woman|boy|girl|patient|child|infant|consumption|eating|ingestion|food|meat)\b', abstract): return False
    if re.search(r'\b(dog|cat|horse|cow|animal)s?\b was presented', text): return False
    if re.search(r'\b(?:presented to the veterinary|admitted to the veterinary)\b', text): return False
    if re.search(r'a \d+[- ](?:year|month|week|day)[- ]old (?:dog|cat|horse|cow)\b', text): return False
    return True

diag_pattern = r'elisa|western blot|serolog|seropositive|antibodies|antibody|igg|igm|histolog|biopsy|larva|patholog|pcr|molecular|polymerase chain reaction|imaging|mri|oct|clinical|eosinophi|funduscopy|ultrasound'

def is_strict(row):
    title = str(row.get('Title', ''))
    abstract_val = row.get('Raw_Abstract')
    abstract = str(abstract_val) if pd.notna(abstract_val) else ''
    pmid = str(row.get('PMID', ''))
    fulltext = str(pmid_fulltexts.get(pmid, ''))
    
    text_to_search = (title + " " + abstract + " " + fulltext).lower()
    
    if not re.search(r'toxocara|toxocariasis|toxocarosis|larva migrans', text_to_search):
        return False
        
    if pd.isna(abstract_val) and not fulltext and re.search(r'toxocariasis|toxocarosis', title.lower()):
        return True

    if not re.search(diag_pattern, text_to_search):
        return False
    return True

def classify_row(row):
    if not is_human(row):
        return "Excluded (Nonhuman)"
    if not is_strict(row):
        return "Excluded (Uncertain diagnosis)"
    return "Included"

df['Inclusion Status'] = df.apply(classify_row, axis=1)

df.to_csv('case_reports.csv', index=False)
print("Classification complete. Created column 'Inclusion Status'")
print("Counts:")
print(df['Inclusion Status'].value_counts())
