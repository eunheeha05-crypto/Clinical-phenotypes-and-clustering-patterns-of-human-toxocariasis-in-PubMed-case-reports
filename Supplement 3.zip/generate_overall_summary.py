import pandas as pd
import numpy as np
from scipy.stats import fisher_exact
from scipy.stats.contingency import odds_ratio as scipy_odds_ratio
import itertools

def get_interpretation(s1, s2):
    vlm_symptoms = {'Asthma', 'Cough', 'Dyspnea', 'Fever', 'Hepatomegaly', 'Pruritus', 'Myocarditis', 'Eosinophilia'}
    olm_symptoms = {'Blindness', 'Uveitis', 'Strabismus'}
    ntm_symptoms = {'Headache', 'Meningitis', 'Seizures'}
    
    if s1 in vlm_symptoms and s2 in vlm_symptoms:
        return "Visceral Larva Migrans (VLM) Complex: Indicates systemic inflammatory response and organ migration."
    elif s1 in olm_symptoms and s2 in olm_symptoms:
        return "Ocular Larva Migrans (OLM) Complex: Reflects isolated ocular infection and related visual damage."
    elif s1 in ntm_symptoms and s2 in ntm_symptoms:
        return "Neurotoxocariasis (NTM) Complex: Represents larval invasion of the central nervous system."
    elif (s1 in ntm_symptoms and s2 in vlm_symptoms) or (s2 in ntm_symptoms and s1 in vlm_symptoms):
        return "Mixed Systemic/Neurological: Disseminated disease involving both viscera and CNS."
    elif (s1 in olm_symptoms and s2 in vlm_symptoms) or (s2 in olm_symptoms and s1 in vlm_symptoms):
        return "Mixed Oculo-Visceral: Atypical presentation involving both systemic organs and eyes."
    elif (s1 in olm_symptoms and s2 in ntm_symptoms) or (s2 in olm_symptoms and s1 in ntm_symptoms):
        return "Mixed Oculo-Neurological: Severe atypical presentation indicating multi-system dissemination."
    return "Other Association / Atypical presentation."

def main():
    df = pd.read_csv("case_reports_mesh_standardized.csv")
    
    # Extract symptoms
    all_symptoms = set()
    for item in df['MeSH_Symptoms']:
        if pd.isna(item) or item == "Asymptomatic/Covert":
            continue
        terms = [t.strip() for t in item.split(',')]
        all_symptoms.update(terms)
        
    symptoms_list = sorted(list(all_symptoms))
    
    # One-hot encode
    symptom_data = []
    for index, row in df.iterrows():
        row_symptoms = row['MeSH_Symptoms']
        row_dict = {}
        if pd.isna(row_symptoms) or row_symptoms == "Asymptomatic/Covert":
            current_symptoms = []
        else:
            current_symptoms = [t.strip() for t in row_symptoms.split(',')]
            
        for sym in symptoms_list:
            row_dict[sym] = 1 if sym in current_symptoms else 0
        symptom_data.append(row_dict)
        
    df_symptoms = pd.DataFrame(symptom_data)
    
    # Filter rare symptoms to match previous
    df_symptoms = df_symptoms.loc[:, (df_symptoms.sum(axis=0) >= 2)]
    features = df_symptoms.columns.tolist()
    
    results = []
    for s1, s2 in itertools.combinations(features, 2):
        crosstab = pd.crosstab(df_symptoms[s1], df_symptoms[s2])
        if crosstab.shape == (2,2):
            odds, p_value = fisher_exact(crosstab)
            res = scipy_odds_ratio(crosstab)
            ci = res.confidence_interval(0.95)
            ci_low, ci_high = ci.low, ci.high
        else:
            p_value = 1.0
            odds = np.nan
            ci_low, ci_high = np.nan, np.nan
            
        # Only keep significant relationships (< 0.05) to not clutter the report, or keep all?
        # Let's keep those with p < 0.05 or co-occurrence > 0
        cooccur = df_symptoms[(df_symptoms[s1]==1) & (df_symptoms[s2]==1)].shape[0]
        
        if cooccur > 0 and p_value < 0.05:
            if p_value < 0.0001:
                p_str = "< 0.0001"
            else:
                p_str = f"{p_value:.4f}"
                
            sig_level = "Nominal (p < 0.01)" if p_value <= 0.01 else "Nominal (0.01 < p <= 0.05)"
            
            correlation_val = df_symptoms[s1].corr(df_symptoms[s2])
            if pd.isna(correlation_val):
                correlation_dir = "None"
            elif correlation_val > 0:
                correlation_dir = "Positive"
            elif correlation_val < 0:
                correlation_dir = "Negative"
            else:
                correlation_dir = "None"
                
            if np.isinf(odds):
                or_str = "inf"
            elif pd.isna(odds):
                or_str = "NaN"
            else:
                or_str = f"{odds:.2f}"
                
            if pd.isna(ci_low) or pd.isna(ci_high):
                ci_str = "NaN"
            else:
                low_str = "inf" if np.isinf(ci_low) else f"{ci_low:.2f}"
                high_str = "inf" if np.isinf(ci_high) else f"{ci_high:.2f}"
                ci_str = f"[{low_str}, {high_str}]"
            
            results.append({
                "Feature 1": s1,
                "Feature 2": s2,
                "Co-occurrence Count": cooccur,
                "Odds Ratio": or_str,
                "95% exact CI": ci_str,
                "P-value": p_str,
                "Nominal p-value tier": sig_level,
                "Interpretation": correlation_dir
            })
            
    res_df = pd.DataFrame(results)
    res_df.sort_values(by=["Nominal p-value tier", "Co-occurrence Count"], ascending=[True, False], inplace=True)
    res_df.to_csv("overall_symptom_summary.csv", index=False)
    print("Exported to overall_symptom_summary.csv")

if __name__ == "__main__":
    main()
