import pandas as pd
from Bio import Entrez
import time
import re

Entrez.email = "example@example.com"

# 1. Load data
input_file = "case_reports_final.csv"
df = pd.read_csv(input_file)
pmids = df['PMID'].astype(str).tolist()

print(f"Fetching data for {len(pmids)} PMIDs...")

# 2. Fetch from PubMed
pmid_data = {}
chunk_size = 100
for i in range(0, len(pmids), chunk_size):
    chunk = pmids[i:i+chunk_size]
    try:
        handle = Entrez.efetch(db="pubmed", id=",".join(chunk), retmode="xml")
        records = Entrez.read(handle)
        
        for article in records['PubmedArticle']:
            pmid = str(article['MedlineCitation']['PMID'])
            
            # Extract Affiliation (Country)
            country = "Unknown"
            try:
                authors = article['MedlineCitation']['Article']['AuthorList']
                if len(authors) > 0 and 'AffiliationInfo' in authors[0] and len(authors[0]['AffiliationInfo']) > 0:
                    affiliation = authors[0]['AffiliationInfo'][0]['Affiliation']
                    # A very basic heuristic: get the last word before the email or end of string, excluding dots
                    # Countries are usually the last part of the affiliation.
                    # e.g. "... Seoul, Republic of Korea.", "... Vienna, Austria."
                    parts = affiliation.split(',')
                    last_part = parts[-1].strip().strip('.')
                    
                    # sometimes emails are appended
                    email_drop = last_part.split(' ')
                    for comp in reversed(email_drop):
                        if "@" not in comp and len(comp) > 2:
                            country = comp.strip().strip('.')
                            break
                            
                    # Manual fixes for common cases
                    if "Korea" in affiliation:
                        country = "South Korea"
                    elif "Taiwan" in affiliation:
                        country = "Taiwan"
                    elif "Japan" in affiliation:
                        country = "Japan"
                    elif "China" in affiliation:
                        country = "China"
                    elif "Italy" in affiliation:
                        country = "Italy"
                    elif "Switzerland" in affiliation:
                        country = "Switzerland"
                    elif "Peru" in affiliation:
                        country = "Peru"
                    elif "Austria" in affiliation:
                        country = "Austria"
                    elif "Poland" in affiliation:
                        country = "Poland"
                    elif "USA" in affiliation or "United States" in affiliation:
                        country = "USA"
            except Exception as e:
                print(f"No affialiation for {pmid}")
                pass
                
            # Extract Abstract
            abstract_text = ""
            try:
                abstract_list = article['MedlineCitation']['Article']['Abstract']['AbstractText']
                for chunk_text in abstract_list:
                    abstract_text += str(chunk_text) + " "
            except KeyError:
                pass
                
            abstract_lower = abstract_text.lower()
            
            # Basic analysis for cultural/dietary risk factors
            risk_factors = []
            
            # 1. Raw liver/meat (Cultural Dietary Habit)
            dietary_keywords = ["raw", "liver", "meat", "beef", "cow", "pork", "eating", "ingestion", "food-borne"]
            if any(k in abstract_lower for k in ["raw liver", "raw meat", "raw cow", "raw beef", "raw pork"]):
                risk_factors.append("Raw Meat/Liver Consumption")
            # Secondary check for just mentioning liver ingestion
            elif "liver" in abstract_lower and ("raw" in abstract_lower or "ingest" in abstract_lower or "eat" in abstract_lower):
                # Ensure it's not talking about the organ involvement (e.g. "liver abscess")
                if "eating" in abstract_lower or "consumption" in abstract_lower or "diet" in abstract_lower:
                    risk_factors.append("Raw Meat/Liver Consumption")
                    
            # 2. Geophagia / Soil exposure
            if any(k in abstract_lower for k in ["geophagia", "dirt", "soil", "sand", "sandbox", "pica"]):
                risk_factors.append("Geophagia / Soil Exposure")
                
            # 3. Zoonotic / Pet / Farm
            if any(k in abstract_lower for k in ["pet", "dog", "puppy", "cat", "kitten", "farm", "animal feces", "coprophagia"]):
                risk_factors.append("Pet/Farm/Feces Exposure")
                
            if len(risk_factors) == 0:
                risk_factors = ["Not explicitly stated in abstract"]
                
                
            pmid_data[pmid] = {
                "Country": country,
                "Risk Factors Identified": ", ".join(risk_factors)
            }
        
    except Exception as e:
        print(f"Error fetching chunk: {e}")

# 3. Merge data
df['Country'] = df['PMID'].astype(str).map(lambda p: pmid_data.get(p, {}).get('Country', 'Unknown'))
df['Reported Risk Factor'] = df['PMID'].astype(str).map(lambda p: pmid_data.get(p, {}).get('Risk Factors Identified', 'Unknown'))

# Format for output
output_file = "case_reports_with_demographics.csv"
df.to_csv(output_file, index=False)
print(f"Saved demographic data to {output_file}")
