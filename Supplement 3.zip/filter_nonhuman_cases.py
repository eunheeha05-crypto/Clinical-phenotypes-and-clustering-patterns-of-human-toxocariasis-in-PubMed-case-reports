import pandas as pd
import re

# Load the dataset
# Load the dataset
input_file = 'case_reports.csv'
output_human_file = 'case_reports_human.csv'
output_excluded_file = 'case_reports_excluded.csv'

try:
    df = pd.read_csv(input_file)
    print(f"Loaded {len(df)} records from {input_file}")
except FileNotFoundError:
    print(f"Error: {input_file} not found.")
    exit(1)

# Define keywords for exclusion (case-insensitive)
# We use regex word boundaries \b to ensure we match whole words
exclusion_keywords = [
    r'\bdog\b', r'\bdogs\b', r'\bcanine\b', r'\bpuppy\b', r'\bpuppies\b',
    r'\bcat\b', r'\bcats\b', r'\bfeline\b', r'\bkitten\b', r'\bkittens\b',
    r'\bhorse\b', r'\bhorses\b', r'\bequine\b', r'\bfoal\b', r'\bfoals\b', r'\bmare\b', r'\bstallion\b',
    r'\bcow\b', r'\bcows\b', r'\bbovine\b', r'\bcalf\b', r'\bcalves\b', r'\bcattle\b',
    r'\bsheep\b', r'\bovine\b', r'\blamb\b', r'\blambs\b',
    r'\bgoat\b', r'\bgoats\b', r'\bcaprine\b',
    r'\bpig\b', r'\bpigs\b', r'\bporcine\b', r'\bswine\b', r'\bpiglet\b', r'\bpiglets\b',
    r'\banimal\b', r'\banimals\b',
    r'\brat\b', r'\brats\b', r'\bmouse\b', r'\bmice\b', r'\bmurine\b',
    r'\brabbit\b', r'\brabbits\b',
    r'\bmonkey\b', r'\bmonkeys\b', r'\bprimate\b', r'\bprimates\b',
    r'\bspecimen\b', # Often used in zoological descriptions
    r'\bDidelphis\b', # Opossum
    r'\bwildlife\b',
    r'\bzoo\b'
]

# Compile the regex pattern
# Join all keywords with OR operator |
exclusion_pattern = '|'.join(exclusion_keywords)

# Function to check if a title contains any exclusion keywords
def is_excluded(title):
    if pd.isna(title):
        return False
    return bool(re.search(exclusion_pattern, title, re.IGNORECASE))

# Apply filtering
# We will create a boolean mask
mask = df['Title'].apply(is_excluded)

# Separate the dataframes
excluded_df = df[mask]
human_df = df[~mask]

# Save the results
human_df.to_csv(output_human_file, index=False)
excluded_df.to_csv(output_excluded_file, index=False)

print(f"Filtering complete.")
print(f"Total records: {len(df)}")
print(f"Human cases kept: {len(human_df)}")
print(f"Nonhuman/Excluded cases: {len(excluded_df)}")
print(f"Excluded cases saved to: {output_excluded_file}")
print(f"Human cases saved to: {output_human_file}")
