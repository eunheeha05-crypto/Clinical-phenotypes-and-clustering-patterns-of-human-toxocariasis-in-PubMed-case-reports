import pandas as pd
import numpy as np

def parse_eo(eo_text):
    if pd.isna(eo_text) or eo_text == 'N/A' or eo_text == 'No explicit mention found in full text':
        return 0
    txt = str(eo_text).lower()
    if 'eosinophilia' in txt or '%' in txt or 'x 10' in txt or '/ul' in txt or '/mm3' in txt:
        if 'normal' in txt and 'hypereosinophilia' not in txt: return 0
        return 1
    return 0

serology_keywords = ['elisa', 'igg', 'seropositive', 'serology', 'antibod', 'western blot', 'serological']
def has_serology(txt):
    if pd.isna(txt): return False
    txt = str(txt).lower()
    return any(k in txt for k in serology_keywords)

def main():
    df_mesh = pd.read_csv("case_reports_mesh_standardized.csv")
    df_demo = pd.read_csv("case_reports_with_demographics.csv")
    df_eo = pd.read_csv("full_text_eosinophilia_reanalysis.csv")

    df_mesh['PMID'] = df_mesh['PMID'].astype(str)
    df_demo['PMID'] = df_demo['PMID'].astype(str)
    df_eo['PMID'] = df_eo['PMID'].astype(str)

    # Calculate markers
    eo_map = {}
    for _, row in df_eo.iterrows():
        eo_map[row['PMID']] = parse_eo(row['Full Text Eo Mentions'])

    sero_map = {}
    for _, row in df_demo.iterrows():
        sero_map[row['PMID']] = 1 if has_serology(row['Raw_Abstract']) else 0

    # Inject into df_mesh
    for idx, row in df_mesh.iterrows():
        pmid = row['PMID']
        current_symptoms = str(row['MeSH_Symptoms']) if pd.notna(row['MeSH_Symptoms']) else ""
        if current_symptoms == "Asymptomatic/Covert":
            current_symptoms = ""
            
        new_syms = [s.strip() for s in current_symptoms.split(',')] if current_symptoms else []
        
        # Remove old ones if they were there (just in case)
        new_syms = [s for s in new_syms if s not in ['Eosinophilia', 'Seropositivity']]
        
        if eo_map.get(pmid, 0) == 1:
            new_syms.append('Eosinophilia')
        if sero_map.get(pmid, 0) == 1:
            new_syms.append('Seropositivity')
            
        final_str = ", ".join(new_syms) if new_syms else "Asymptomatic/Covert"
        df_mesh.at[idx, 'MeSH_Symptoms'] = final_str
        
    df_mesh.to_csv("case_reports_mesh_standardized.csv", index=False)
    print("Injected Eosinophilia and Seropositivity into MeSH_Symptoms.")

    # Inject Seropositivity into df_demo for clustering_analysis
    df_demo['Serology_Positive'] = df_demo['PMID'].map(sero_map)
    df_demo.to_csv("case_reports_with_demographics.csv", index=False)
    print("Injected Serology_Positive into case_reports_with_demographics.csv.")

if __name__ == "__main__":
    main()
