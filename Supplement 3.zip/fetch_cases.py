import sys
import os
import csv
import json
import re
from Bio import Entrez
import xml.etree.ElementTree as ET

# Configure Entrez
Entrez.email = "researcher@example.com"  # Using generic email, user should update if hitting limits
Entrez.tool = "ToxocariasisCaseExtractor"

def search_cases():
    term = "('Toxocariasis' OR 'Toxocara') AND 'Case Reports' [Publication Type] AND 2005:2025[dp] AND free full text[sb]"
    print(f"Searching PubMed for: {term}")
    handle = Entrez.esearch(db="pubmed", term=term, retmax=500) # Increased limit to get a good sample
    record = Entrez.read(handle)
    handle.close()
    return record["IdList"]

def fetch_details(id_list):
    print(f"Fetching details for {len(id_list)} articles...")
    ids = ",".join(id_list)
    handle = Entrez.efetch(db="pubmed", id=ids, retmode="xml")
    records = Entrez.read(handle)
    handle.close()
    return records

def extract_variables(article):
    # This is a heuristic extraction. Real extraction likely requires NLP on full text (PMC).
    # PubMed XML often only contains Abstracts.
    # We will try to extract from AbstractText.
    
    medline = article.get("MedlineCitation", {})
    pmid = medline.get("PMID", "Unknown")
    article_data = medline.get("Article", {})
    abstract_list = article_data.get("Abstract", {}).get("AbstractText", [])
    
    # Combine abstract parts
    abstract_text = ""
    if isinstance(abstract_list, list):
        for item in abstract_list:
            if hasattr(item, "title"): # Some AbstractText have labels like "BACKGROUND"
                abstract_text += f"{item.attributes.get('Label', '')}: {item} "
            else:
                abstract_text += f"{item} "
    else:
        abstract_text = str(abstract_list)
        
    title = article_data.get("ArticleTitle", "")
    
    # Simple Regex Extraction (Heuristics)
    age_match = re.search(r"(\d+)\s*[-–]\s*(year|month|week)-old", abstract_text + title, re.IGNORECASE)
    sex_match = re.search(r"\b(male|female|boy|girl|man|woman)\b", abstract_text + title, re.IGNORECASE)
    
    age = age_match.group(0) if age_match else "Not found"
    sex = sex_match.group(0) if sex_match else "Not found"
    
    # For Chief Complaint, try to find "presented with"
    complaint_match = re.search(r"presented with ([^.]+)", abstract_text, re.IGNORECASE)
    complaint = complaint_match.group(1).strip() if complaint_match else "Not explicitly stated in abstract"
    
    # Eosinophils
    eos_match = re.search(r"(eosinophils?|eosinophilia) [^.]*?(\d+(\.\d+)?\s*(%|cells|/mm3|/L))", abstract_text, re.IGNORECASE)
    eosinophils = eos_match.group(0) if eos_match else "Not found"
    
    return {
        "PMID": str(pmid),
        "Title": title,
        "Patient Age": age,
        "Sex": sex,
        "Chief Complaint": complaint,
        "Associated Symptoms": "See Abstract", # Too complex for regex
        "Eosinophil Count": eosinophils,
        "Final Diagnosis": "Toxocariasis (assumed from query)",
        "Raw_Abstract": abstract_text
    }

def main():
    try:
        ids = search_cases()
        if not ids:
            print("No articles found.")
            return

        print(f"Found {len(ids)} articles. Processing...")
        
        # We process in batches of 50 (max per request is usually higher but safe side)
        records = fetch_details(ids)
        
        extracted_data = []
        if 'PubmedArticle' in records:
            for article in records['PubmedArticle']:
                data = extract_variables(article)
                extracted_data.append(data)
        
        # Save JSON
        with open("case_reports.json", "w", encoding="utf-8") as f:
            json.dump(extracted_data, f, indent=4)
        print("Saved case_reports.json")
        
        # Save CSV
        fields = ["PMID", "Title", "Patient Age", "Sex", "Chief Complaint", "Associated Symptoms", "Eosinophil Count", "Final Diagnosis", "Raw_Abstract"]
        with open("case_reports.csv", "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
            writer.writeheader()
            for row in extracted_data:
                writer.writerow(row)
        print("Saved case_reports.csv")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
