import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import silhouette_score
import scipy.stats as stats
import re

def main():
    print("Loading data for Tautology-free Data-Driven Clustering...")
    try:
        df_demo = pd.read_csv("case_reports_with_demographics.csv")
        df_eo = pd.read_csv("full_text_eosinophilia_reanalysis.csv")
    except Exception as e:
        print("Data files missing:", e)
        return

    # Ensure PMIDs are strings for merging
    df_demo['PMID'] = df_demo['PMID'].astype(str)
    df_eo['PMID'] = df_eo['PMID'].astype(str)
    
    # Check if df_demo already has the columns from df_eo just in case
    if 'Full Text Eo Mentions' in df_demo.columns:
        df = df_demo
    else:
        df = pd.merge(df_demo, df_eo[['PMID', 'Full Text Eo Mentions']], on='PMID', how='left')

    # FEATURE ENGINEERING (Zero Tautology)
    features = pd.DataFrame(index=df.index)
    
    # 1. Demographics
    features['Age_Child'] = df['Patient Age'].apply(lambda x: 1 if pd.notna(x) and ('child' in str(x).lower() or 'boy' in str(x).lower() or 'girl' in str(x).lower() or (re.search(r'\d+', str(x)) and int(re.search(r'\d+', str(x)).group()) < 18)) else 0)
    
    # 2. Eosinophilia (Validated from Full Text)
    def parse_eo(eo_text):
        if pd.isna(eo_text) or eo_text == 'N/A' or eo_text == 'No explicit mention found in full text':
            return 0
        txt = str(eo_text).lower()
        if 'eosinophilia' in txt or '%' in txt or 'x 10' in txt or '/ul' in txt or '/mm3' in txt:
            # If they mention 'normal eosinophil' or 'negative', we shouldn't flag it, but for a simple heuristic, 
            # mentions of hypereosinophilia or actual counts usually imply positive finding in case reports.
            if 'normal' in txt and 'hypereosinophilia' not in txt: return 0
            return 1
        return 0
    features['Eosinophilia_High'] = df['Full Text Eo Mentions'].apply(parse_eo)
    
    # 3. Organs (Independent, strictly no nested symptoms)
    organs = ["Eye", "CNS", "Liver", "Lung", "Heart"]
    for org in organs:
        features[f"Organ_{org}"] = df['Organ Involvement'].apply(lambda x: 1 if pd.notna(x) and org.lower() in str(x).lower() else 0)
        
    # 4. Risk Factors
    features['Risk_Geophagia'] = df['Reported Risk Factor'].apply(lambda x: 1 if pd.notna(x) and 'Geophagia' in str(x) else 0)
    features['Risk_PetFarm'] = df['Reported Risk Factor'].apply(lambda x: 1 if pd.notna(x) and 'Pet' in str(x) else 0)
    
    # 5. Serology validation
    features['Serology_Positive'] = df['Serology_Positive'] if 'Serology_Positive' in df.columns else 0
    
    # Store Eosinophilia_High safely
    has_eo = features['Eosinophilia_High'].copy()
    
    # Drop constant features to avoid math errors
    features = features.loc[:, (features != features.iloc[0]).any()] 
    
    # Restore Eosinophilia_High if dropped
    features['Eosinophilia_High'] = has_eo
    
    # DETERMINE OPTIMAL K via Silhouette
    best_k = 2
    best_score = -1
    best_labels = None
    
    print("Testing cluster numbers (K=2 to K=5) using Agglomerative Clustering...")
    for k in range(2, 6):
        model = AgglomerativeClustering(n_clusters=k, metric='euclidean', linkage='ward')
        labels = model.fit_predict(features)
        score = silhouette_score(features, labels)
        print(f"K={k} -> Silhouette Score: {score:.3f}")
        if score > best_score:
            best_score = score
            best_k = k
            best_labels = labels
            
    print(f"\n=> Selected optimal K={best_k} (Highest Silhouette Score)")
    df['Data_Driven_Cluster'] = best_labels
    
    # SAVE NEW DATA
    df.to_csv("case_reports_clustered_rigorous.csv", index=False)
    
    # HEATMAP (Tautology-Free)
    corr_matrix = features.corr()
    plt.figure(figsize=(10, 8))
    sns.heatmap(corr_matrix, cmap='coolwarm', center=0, annot=True, fmt=".2f", vmin=-1, vmax=1)
    plt.title("Tautology-Free Feature Correlation Heatmap")
    plt.tight_layout()
    plt.savefig("tautology_free_heatmap.png")
    print("Saved heatmap to tautology_free_heatmap.png")
    
    # SYMPTOM ONLY HEATMAP
    symptom_features = features[[col for col in features.columns if col.startswith('Organ_')]]
    symptom_corr = symptom_features.corr()
    plt.figure(figsize=(8, 6))
    sns.heatmap(symptom_corr, cmap='coolwarm', center=0, annot=True, fmt=".2f", vmin=-1, vmax=1)
    plt.title("Symptom-Only Feature Correlation Heatmap")
    plt.tight_layout()
    plt.savefig("symptom_only_heatmap.png")
    print("Saved symptom-only heatmap to symptom_only_heatmap.png")
    
    # CLUSTER REPORT
    with open("rigorous_cluster_report.md", "w") as f:
        f.write("# Rigorous Data-Driven Clustering Report\n\n")
        f.write("## Methodology\n")
        f.write("*   **De-duplication**: Nested symptoms (like uveitis) were absorbed fully into Organ domains (Eye) to remove tautological correlations.\n")
        f.write(f"*   **Clustering Engine**: Agglomerative Hierarchical Clustering. Evaluated K=2 to 5 automatically.\n")
        f.write(f"*   **Optimal K Selected**: K={best_k} (Silhouette Score: {best_score:.3f})\n\n")
        
        f.write("## Cluster Profiles\n")
        for k in range(best_k):
            cluster_subset = features[df['Data_Driven_Cluster'] == k]
            f.write(f"### Phenotype Cluster {k + 1} (n={len(cluster_subset)})\n")
            # Calculate prevalences
            means = cluster_subset.mean().sort_values(ascending=False) * 100
            for feat, val in means.items():
                if val > 15: # Arbitrary threshold to show dominating traits
                    f.write(f"- **{feat}**: {val:.1f}%\n")
            f.write("\n")
            
        f.write("## Oculo-Visceral Eosinophilia Validation\n")
        # Direct check as requested by reviewer
        mix_mask = (features['Organ_Eye'] == 1) & (features[['Organ_Liver', 'Organ_Lung', 'Organ_CNS', 'Organ_Heart']].sum(axis=1) > 0)
        mixed_cases = features[mix_mask]
        f.write(f"Identified {len(mixed_cases)} strict Oculo-Visceral Mixed cases.\n")
        if len(mixed_cases) > 0:
            eo_rate = mixed_cases['Eosinophilia_High'].mean() * 100
            f.write(f"- Full-Text Confirmed Eosinophilia Rate in these cases: {eo_rate:.1f}%\n")
            f.write("> **Analysis**: This replaces abstract-only assumptions with strict full-text data.\n")

    print("Completed Rigorous Clustering Pipeline.")

if __name__ == "__main__":
    main()
