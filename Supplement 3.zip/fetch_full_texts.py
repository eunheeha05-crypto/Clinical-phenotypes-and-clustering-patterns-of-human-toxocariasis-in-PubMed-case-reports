import pandas as pd
import json
import re
import os

print("Loading final cases...")
df = pd.read_csv('case_reports_final.csv')

pmid_fulltexts = {}
if os.path.exists('pmid_fulltexts.json'):
    with open('pmid_fulltexts.json', 'r', encoding='utf-8') as f:
        pmid_fulltexts = json.load(f)

results = []
def extract_eosinophil_sentences(text):
    sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', text)
    matched = []
    for s in sentences:
        s_lower = s.lower()
        if 'eosinophil' in s_lower or 'hypereosinophilia' in s_lower or ' eo ' in s_lower or ' eos ' in s_lower:
            clean_s = " ".join(s.split())
            if len(clean_s) > 10:
                matched.append(clean_s)
    return " | ".join(matched)

for index, row in df.iterrows():
    pmid = str(row['PMID'])
    organs = row['Organ Involvement']
    old_eo = row['Eosinophil Count']
    
    full_text = pmid_fulltexts.get(pmid, "")
    
    if full_text and "No Abstract Found" not in full_text and "Error Fetching" not in full_text:
        eo_sentences = extract_eosinophil_sentences(full_text)
        if not eo_sentences:
            eo_sentences = "No explicit mention found in available text"
        
        # Simple heuristic to guess if it's a full PMC text or just an abstract
        has_full_text_label = "Yes (PMC)" if len(full_text.strip()) > 3000 else "Abstract Fallback"
        
        results.append({
            'PMID': pmid,
            'Has_Full_Text': has_full_text_label,
            'Organ Involvement': organs,
            'Old Eo Count': old_eo,
            'Full Text Eo Mentions': eo_sentences
        })
    else:
        results.append({
            'PMID': pmid,
            'Has_Full_Text': 'No Text Available',
            'Organ Involvement': organs,
            'Old Eo Count': old_eo,
            'Full Text Eo Mentions': 'No explicit mention found in available text'
        })

out_df = pd.DataFrame(results)
out_df.to_csv("full_text_eosinophilia_reanalysis.csv", index=False)
print("Saved analysis to full_text_eosinophilia_reanalysis.csv")

def is_oculo_visceral(organs):
    if pd.isna(organs):
        return False
    o = str(organs).lower()
    has_ocular = 'eye' in o or 'ocular' in o
    has_visceral = 'liver' in o or 'lung' in o or 'cns' in o or 'neuro' in o or 'heart' in o or 'systemic' in o
    return has_ocular and has_visceral

oculo_visceral_cases = out_df[out_df['Organ Involvement'].apply(is_oculo_visceral)]
print("\n--- Oculo-Visceral Mixed Cases ---")
for _, row in oculo_visceral_cases.iterrows():
    print(f"PMID: {row['PMID']} | Full Text Extracted: {row['Has_Full_Text']}")
    print("Mentions in Full Text:")
    try:
        print(row['Full Text Eo Mentions'] + "\n")
    except UnicodeEncodeError:
        print(row['Full Text Eo Mentions'].encode('ascii', errors='ignore').decode() + "\n")
