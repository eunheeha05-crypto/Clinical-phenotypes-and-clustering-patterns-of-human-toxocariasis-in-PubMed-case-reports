import pandas as pd
import re
import os
import json

def main():
    df = pd.read_csv("case_reports_with_demographics.csv")
    print(f"Loading N={len(df)} case reports...")
    
    pmid_fulltexts = {}
    if os.path.exists('pmid_fulltexts.json'):
        with open('pmid_fulltexts.json', 'r', encoding='utf-8') as f:
            pmid_fulltexts = json.load(f)

    mesh_dictionary = {
        "Fever": [r'\bfever', r'\bpyrexia', r'\btemperature'],
        "Pruritus": [r'\bitch', r'\bpruritus', r'\brash', r'\burticaria'],
        "Dyspnea": [r'\bdyspnea', r'\bbreath', r'\bwheez'],
        "Cough": [r'\bcough'],
        "Asthma": [r'\basthma'],
        "Blindness": [r'\bblind', r'\bvision loss', r'\bdecreased vision', r'\bvisual'],
        "Uveitis": [r'\buveitis', r'\bretinitis', r'\bchorioretinitis', r'\bchoroiditis', r'\bpapillitis', r'\bvitritis'],
        "Strabismus": [r'\bstrabismus', r'\bsquint'],
        "Seizures": [r'\bseizure', r'\bconvulsion', r'\bepilep'],
        "Headache": [r'\bheadache', r'\bmigraine'],
        "Meningitis": [r'\bmeningitis', r'\bencephalitis', r'\bmyelitis', r'\bmeningoencephalitis'],
        "Hepatomegaly": [r'\bhepatomegal', r'\bliver enlarg', r'\bhepatic lesion', r'\bliver abscess'],
        "Myocarditis": [r'\bmyocarditis', r'\bpericarditis', r'\bcardiac'],
        "Eosinophilia": [r'\beosinophil']
    }

    # Extract MeSH terms safely
    def extract_mesh(row):
        pmid = str(row.get('PMID', ''))
        fulltext = str(pmid_fulltexts.get(pmid, ''))
        
        text = str(row.get('Title', '')) + " " + str(row.get('Raw_Abstract', '')) + " " + str(row.get('Associated Symptoms', '')) + " " + str(row.get('Chief Complaint', '')) + " " + fulltext
        text = text.lower()
        
        found_mesh = []
        for mesh_name, patterns in mesh_dictionary.items():
            combined_pattern = '|'.join(patterns)
            if re.search(combined_pattern, text):
                found_mesh.append(mesh_name)
                
        return ", ".join(found_mesh) if found_mesh else "Asymptomatic/Covert"

    df['MeSH_Symptoms'] = df.apply(extract_mesh, axis=1)
    
    # Save the expanded dataset
    df.to_csv("case_reports_mesh_standardized.csv", index=False)
    print("Process Complete. MeSH standardizations mapped and sorted.")
    
    # Quick Summary
    all_symps = []
    for s in df['MeSH_Symptoms']:
        if s != "Asymptomatic/Covert":
            all_symps.extend([x.strip() for x in s.split(",")])
    from collections import Counter
    print("\nTop MeSH Terms Found:")
    for k, v in Counter(all_symps).most_common(10):
        print(f"{k}: {v}")

if __name__ == "__main__":
    main()
