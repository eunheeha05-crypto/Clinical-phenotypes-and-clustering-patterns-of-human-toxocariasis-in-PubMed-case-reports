import matplotlib.pyplot as plt
import matplotlib.patches as patches
import pandas as pd
import json
import re
import os

def draw_prisma_flow():
    # 1. Dynamically Calculate Numbers
    df = pd.read_csv('case_reports.csv')
    n_identified = len(df)
    n_screened = n_identified
    
    # Human filter logic identical to process_dataset.py
    def is_human(row):
        title = str(row.get('Title', '')).lower()
        abstract = str(row.get('Raw_Abstract', '')).lower()
        text = title + " " + abstract
        if re.search(r'\bin a dog\b|\bin a cat\b|\bin dogs\b|\bin cats\b|\banimal model\b', title): return False
        if re.search(r'\bveterinary\b', title) and not re.search(r'\b(student|worker|technician|staff|profession)\b', title): return False
        strong_animals = r'\b(cat|cats|dog|dogs|macaque|macaques|mice|mouse|rat|rats|feline|canine|horse|horses|cow|cows|foal|foals|opossum|didelphis|pig|pigs|sheep|alpaca|porcine|bovine|equine|puppy|puppies|kitten|kittens)\b'
        if re.search(strong_animals, title) and not re.search(r'\b(human|man|woman|boy|girl|patient|child|infant|consumption|eating|ingestion|food|meat)\b', title):
            if not re.search(r'\b(human|man|woman|boy|girl|patient|child|infant|consumption|eating|ingestion|food|meat)\b', abstract): return False
        if re.search(r'\b(dog|cat|horse|cow|animal)s?\b was presented', text): return False
        if re.search(r'\b(?:presented to the veterinary|admitted to the veterinary)\b', text): return False
        if re.search(r'a \d+[- ](?:year|month|week|day)[- ]old (?:dog|cat|horse|cow)\b', text): return False
        return True
    
    df_human = df[df.apply(is_human, axis=1)]
    n_human_excluded = n_identified - len(df_human)
    n_assessed = len(df_human)
    
    # Final data
    df_final = pd.read_csv('case_reports_final.csv')
    n_included = len(df_final)
    n_strict_excluded = n_assessed - n_included

    # 2. Figure size
    fig, ax = plt.subplots(figsize=(10, 10))
    ax.set_xlim(0, 11)
    ax.set_ylim(0, 11)
    ax.axis('off')

    # Centers
    x_center = 2.8
    # Y positions
    y_1 = 9.0
    y_2 = 6.8
    y_3 = 4.6
    y_4 = 2.4
    
    # Exclusion box Y-centers
    y_ex1 = (y_2 + y_3) / 2
    y_ex2 = (y_3 + y_4) / 2
    
    # Excluded box x-center
    x_ex = x_center + 4.8
    
    # Box Dimensions
    w_box = 4.0
    h_box1 = 1.0
    h_box2 = 1.0
    h_box3 = 1.0
    h_box4 = 1.0
    
    w_exbox = 4.0
    h_ex1 = 1.0
    h_ex2 = 1.3
    
    # Helper to draw box
    def draw_box(x, y, w, h, text):
        box = patches.FancyBboxPatch(
            (x - w/2, y - h/2), w, h,
            boxstyle="round,pad=0.1,rounding_size=0.2",
            linewidth=1.0, edgecolor='black', facecolor='white',
            zorder=10
        )
        ax.add_patch(box)
        
        ax.text(x, y, text, ha='center', va='center', fontsize=11, family='sans-serif', zorder=11, wrap=True)
        
        pad = 0.1
        return {
            'top': y + h/2 + pad,
            'bottom': y - h/2 - pad,
            'left': x - w/2 - pad,
            'right': x + w/2 + pad,
            'center_x': x,
            'center_y': y
        }

    # Strings
    t1_str = f"Records identified from\nPubMed database\n(n = {n_identified})"
    t2_str = f"Records screened\n(n = {n_screened})"
    t3_str = f"Full-text / Abstracts assessed\nfor eligibility\n(n = {n_assessed})"
    t4_str = f"Studies included in\nqualitative synthesis and\ndata analysis\n(n = {n_included})"
    
    tex1_str = f"Records excluded\n(Non-human or animal models)\n(n = {n_human_excluded})"
    tex2_str = f"Records excluded\n(Uncertain diagnosis, lack of objective\nproof, or non-Toxocariasis)\n(n = {n_strict_excluded})"

    # Draw Boxes
    b1 = draw_box(x_center, y_1, w_box, h_box1, t1_str)
    b2 = draw_box(x_center, y_2, w_box, h_box2, t2_str)
    b3 = draw_box(x_center, y_3, w_box, h_box3, t3_str)
    b4 = draw_box(x_center, y_4, w_box, h_box4, t4_str)
    
    be1 = draw_box(x_ex, y_ex1, w_exbox, h_ex1, tex1_str)
    be2 = draw_box(x_ex, y_ex2, w_exbox, h_ex2, tex2_str)

    # Draw Connections
    arrow_props = dict(arrowstyle="->", lw=1.2, color='black', shrinkA=0, shrinkB=0)
    
    # 1. Vertical Arrows
    ax.annotate("", xy=(x_center, b2['top']), xytext=(x_center, b1['bottom']), arrowprops=arrow_props, zorder=20)
    ax.annotate("", xy=(x_center, b3['top']), xytext=(x_center, b2['bottom']), arrowprops=arrow_props, zorder=20)
    ax.annotate("", xy=(x_center, b4['top']), xytext=(x_center, b3['bottom']), arrowprops=arrow_props, zorder=20)
    
    # 2. Horizontal Lines branching off
    ax.annotate("", xy=(be1['left'], y_ex1), xytext=(x_center, y_ex1), arrowprops=arrow_props, zorder=20)
    ax.annotate("", xy=(be2['left'], y_ex2), xytext=(x_center, y_ex2), arrowprops=arrow_props, zorder=20)

    plt.title("PRISMA-ScR Flow Diagram for Toxocariasis Case Reports", fontsize=12, pad=20)
    plt.tight_layout()
    plt.savefig('prisma_flow_updated.png', dpi=300, bbox_inches='tight')
    print("prisma_flow_updated.png generated successfully.")

if __name__ == "__main__":
    draw_prisma_flow()
