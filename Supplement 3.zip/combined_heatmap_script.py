import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

def main():
    print("Loading datasets...")
    df_mesh = pd.read_csv("case_reports_mesh_standardized.csv")
    df_demo = pd.read_csv("case_reports_with_demographics.csv")
    
    # Ensure PMIDs are strings
    df_mesh['PMID'] = df_mesh['PMID'].astype(str)
    df_demo['PMID'] = df_demo['PMID'].astype(str)
    
    # Merge on PMID
    df = pd.merge(df_mesh[['PMID', 'MeSH_Symptoms']], df_demo[['PMID', 'Organ Involvement']], on='PMID', how='inner')
    
    features = pd.DataFrame(index=df.index)
    
    # 1. Broad Symptoms (MeSH Symptoms)
    all_symptoms = set()
    for item in df['MeSH_Symptoms']:
        if pd.isna(item) or item == "Asymptomatic/Covert":
            continue
        terms = [t.strip() for t in item.split(',')]
        all_symptoms.update(terms)
        
    symptoms_list = sorted(list(all_symptoms))
    
    for sym in symptoms_list:
        features[sym] = df['MeSH_Symptoms'].apply(
            lambda x: 1 if pd.notna(x) and x != "Asymptomatic/Covert" and sym in [t.strip() for t in x.split(',')] else 0
        )
        
    # Filter out rare features (< 2 occurrences) to reduce noise
    features = features.loc[:, (features.sum(axis=0) >= 2)]
        
    # 2. Organ Involvements
    organs = ["Eye", "CNS", "Liver", "Lung", "Heart"]
    for org in organs:
        features[f"Organ_{org}"] = df['Organ Involvement'].apply(
            lambda x: 1 if pd.notna(x) and org.lower() in str(x).lower() else 0
        )
        
    # Drop columns that are completely constant
    features = features.loc[:, (features != features.iloc[0]).any()]
    
    # CORRELATION MATRIX
    print(f"Calculating correlation for {features.shape[1]} features...")
    corr_matrix = features.corr()
    
    # HEATMAP
    plt.figure(figsize=(14, 12))
    sns.heatmap(corr_matrix, cmap='coolwarm', center=0, annot=False, vmin=-1, vmax=1)
    # Using smaller font for annotations if preferred, or no annotations if too big
    # Let's add annotations if less than 25 features, else omit for clarity
    
    plt.title("Correlation between Broad Symptoms and Organ Involvements")
    plt.tight_layout()
    plt.savefig("combined_symptom_organ_heatmap.png", dpi=300)
    print("Saved combined_symptom_organ_heatmap.png")

if __name__ == "__main__":
    main()
